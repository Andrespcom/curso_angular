


export enum ValidRoles {
    admin = 'admin',
    superUser = 'super-user',
    user = 'user',
}